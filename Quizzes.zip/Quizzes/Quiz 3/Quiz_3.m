%% Question 1 - Didnt get this one
mdl_3link3d;
q = [-pi/6,0,0];

%% Question 2 - Create a 5DOF robot

L1 = Link('alpha',0,'a',1,'d',0,'offset',0);
L2 = Link('alpha',0,'a',1,'d',0,'offset',0);
L3 = Link('alpha',0,'a',1,'d',0,'offset',0);
L4 = Link('alpha',0,'a',1,'d',0,'offset',0);
L5 = Link('alpha',0,'a',1,'d',0,'offset',0);

q = [60,-45,35,-60,0];
q = q .* pi/180;

Robot = SerialLink([L1 L2 L3 L4 L5],'name','Robot');

Robot.plot(q)
Robot.fkine(q)

%% Question 3 - Use trapazodial trajectory thing for max velocity

L1 = Link('alpha',0,'a',1,'d',0,'offset',0);
L2 = Link('alpha',0,'a',1,'d',0,'offset',0);
L3 = Link('alpha',0,'a',1,'d',0,'offset',0);
L4 = Link('alpha',0,'a',1,'d',0,'offset',0);
L5 = Link('alpha',0,'a',1,'d',0,'offset',0);
L6 = Link('alpha',0,'a',1,'d',0,'offset',0);

Qu3_robot = SerialLink([L1 L2 L3 L4 L5],'name','Robot');

q1 = [pi/10, pi/7, pi/5, pi/3, pi/4, pi/6];
q2 = [-pi/10, -pi/7, -pi/5, -pi/3, -pi/4, -pi/6];

steps = 100;

s = lspb(0,1,steps);
qMatrix = nan(steps,6);
for i = 1:steps
    qMatrix(i,:) = (1-s(i))*q1 + s(i)*q2;
end

velocity = zeros(steps,6);
acceleration  = zeros(steps,6);
for i = 2:steps
    velocity(i,:) = qMatrix(i,:) - qMatrix(i-1,:);
    acceleration(i,:) = velocity(i,:) - velocity(i-1,:);
end

min(velocity) %% ignore negative value

%% Question 4 - relative coordinates between ball and end effector (end effector coordinate frame)

mdl_puma560;

q = [0, 30, -80, 0, 50, 0];
q = q .* pi/180;

ball = transl(0.5,0.1,0.6) * trotx(pi/2);

end_effector = p560.fkine(q);

p560.plot(q);
hold on
plot3(0.5,0.1,0.6,'r.');

distance = ball - end_effector

%% Question 5 - Didnt get this one

mdl_puma560

q = transl(0.6,-0.5,0.1);

p560.ikine(q)

%% Question 9 - Y value of sensor measuring 2.2m from end effector

mdl_puma560

q = [0, 45, -80, 0, 45, 0];
q = q .* pi/180;

pos = p560.fkine(q);

distance = sqrt((1 - pos(1,4)^2 + (1 - pos(3,4)^2)));
Y = sqrt((2)^2 - (0.5525)^2) % 2.2m value here

%% Question 10 - Didn't get this one

mdl_puma560

q = [pi/10,0,-pi/2,0,0,0];

