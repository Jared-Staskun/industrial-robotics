%% baxter base - endEffector
clear
clc

mdl_baxter;

qLeft = [0,0,0,0,0,0,0];

baseR = right.base;
baseR = baseR(1:3,4);

qLeft = left.fkine(qLeft);
qLeft = qLeft(1:3,4);

distance = baseR - qLeft;
distance = sqrt(distance(1)^2 + distance(2)^2 + distance(3)^2)

%% baxter endEffector - endEffector
clear
clc

mdl_baxter;

qLeft = [0,pi/10,0,0,0,-pi/10,0];
qRight = [0,-pi/10,0,0,0,pi/10,0];

qLeft = left.fkine(qLeft);
qLeft = qLeft(1:3,4);

qRight = right.fkine(qRight);
qRight = qRight(1:3,4);

distance = qRight - qLeft;
distance = sqrt(distance(1)^2 + distance(2)^2 + distance(3)^2)

%% puma 560 - Ball (Incorrect)
clear
clc

mdl_puma560;

q = [0, 0, 0, 0, 45, 45];
q = q .* (pi/180);

endEffector = p560.fkine(q);
endEffector(3,4) = endEffector(3,4) + 0.8;

ball = transl(0.5,0,0.6) * trotx(pi/2);

p560.plot(q)
hold on
plot3(ball(1,4),ball(2,4),ball(3,4),'r.')

ball = endEffector * ball;

distance = ball - endEffector

%% puma 560 - Jacobian
clear
clc

mdl_puma560;
q = pi/8*ones(1,6);

p560.jacob0(q)

q(2) = q(2) + pi/4;

p560.jacob0(q)

%% puma 560 - floor (0.8m offset)
clear
clc

mdl_puma560;

q = [pi/10,0,0,0,0,0];

endEffector = p560.fkine(q);
endEffector(3,4) = endEffector(3,4) + 0.8;

endEffector(3,4)

%% puma 560 - floor (no offset)
clear
clc

mdl_puma560;

q = [9*pi/10,0,3*pi/8,0,0,2*pi/7];

endEffector = p560.fkine(q);

endEffector(3,4)
