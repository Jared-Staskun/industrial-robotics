mdl_baxter;

q = [1,1,1,0,0,0]
tr=left.fkine(q)