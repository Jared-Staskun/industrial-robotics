trOrigin = eye(4);

%% Move to inital position x = 100, y = 0
tr1 = transl(100,0,0);      
trOrigin = trOrigin * tr1;

for i=0:4
%% drive 90m forward
tr1 = transl(90,0,0);      
trOrigin = trOrigin * tr1;

%% Rotate around z by 45 degrees
rotateAroundXBy10deg = trotz(45*pi/180);
trOrigin = trOrigin * rotateAroundXBy10deg;
end
trOrigin