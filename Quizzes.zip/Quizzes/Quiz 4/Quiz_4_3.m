%% Question 1
r=UR5;

q = [0,55,-90,-45,90,0];
q = q .* (pi/180);

J = r.model.jacobn(q);

m = sym(sqrt(det(J*J')))

%% Question 2

