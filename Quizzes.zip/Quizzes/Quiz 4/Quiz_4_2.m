%% Visual servoid (PBVS)
% The error used to formulate the control problem is expressed in the 3D
% world. This is in contrast with the IBVS where the error is expressed in
% the 2D image plane

%% Collision Detection Line (basic)
% Q: 3 DOF PLANAR, EE is 1m from last joint and 50 triangle in an
% environment 
close
clear
clc
DoF = 4;
triangles = 40;
collisionChecksRequired = DoF*triangles

%% Optimisation
% Damp least squares Q: the damping coefficient in DLS should be as small
% as possible to avoid end-effector error                              TRUE
% The velocity ellipsoid indicates how fast the end-effector can move to
% different orientations (roll, pitch, yaw)                           FALSE

%% Manipulability measure
close
clear
clc
% m = sym(sqrt(det(J*J')));
disp('The measure of manipularity is used to tell how much the cartesian EE can move at a given joint state')



%% Resolved motion rate control
close
clear
clc
disp("A robotic system is REDUNDANT if the Jacobian has MORE COLUMNS THAN ROWS")
disp("Near SINGULAR CONFIGURATIONS, solutions for joint velocities grow to INFINITY")
disp("The Jacobian indicates how the end-effector will move as a function of the current joint state")

%% Near Singularity 3Dof Planar

clear;
close;
clc;
mdl_planar3;

%q = [0 1.5708 -1.5708];
%q = [0 -0.7854 -0.7854];
%q = [0.5 0.5 0.5];
q = [0.7854 -0.7854 0.7854];

%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%
Ja = p3.jacob0(q);
J = Ja(1:2, :);
m = sqrt(det(J*J')) % the smaller this value is, the closer the EE is to a singularity
t = abs(J) * abs(pinv(J)); 
max(max(t)) % the bigger, the closer to singularity

p3.plot(q)
%% Visual Servoing (IBVS)
close
clear
clc
r = UR10(); 
qt =  [1.6; -1; -1.2; -0.5; 0; 0];
focal = 0.08;
pixel = 10e-5;
resolution = [1024 1024];
centre = [512 512];
pStar =  [700 300 300 700; 300 300 700 700]; 
P=[2,2,2,2; -0.4,0.4,0.4,-0.4; 1.4,1.4,0.6,0.6]; 
%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%
q = qt';
cam = CentralCamera('focal', focal, 'pixel', pixel, 'resolution', resolution, 'centre', centre); 
Tc0 = r.model.fkine(q);
cam.T = Tc0;
uv = cam.plot(P);
e = pStar - uv
round(e)
clear

%% Collision detection line (harder)
close
clear
clc
mdl_planar3;

[v,f,fn] = RectangularPrism([2,-1.1,-1],[3,1.1,1]);
steps = 50;
q1 = [pi/3,pi/3,0];
q2 = [-pi/3,-pi/3,0];

%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%
hold on
qMatrix = jtraj(q1,q2,steps);
for i = 1:steps
    result = IsCollision(p3,qMatrix(i,:),f,v,fn);
    if result == 1
        qMatrix(i,:)
        p3.plot(q1);
        pause(3);
        p3.animate(qMatrix(1:i,:));
        break
    end 
end 

%% Near singularity 6DoF
close
clear
clc

mdl_puma560;

% q = [0 0.01 0.79 0 0 0]

% q = [0 2.16 -2.73 0 -0.94 0]

% q = [0 0.78 3 0 0.7 0]

q = [0 1.08 3.14 0 0 0]

%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%
J = p560.jacob0(q);
m = sqrt(det(J*J')) % the smaller, the closer to singularity
t = abs(J) * abs(inv(J)); 
max(max(t)) % the bigger, the closer to singularity

p560.plot(q)
%% Collision detection Points
clc;
clear
close
centerPoint = [3,2,-1]; %%%%%%%%%%% CHANGE %%%%%%%%%%%
radii = [5,5,5]; %%%%%%%%%%% CHANGE %%%%%%%%%%%
[X,Y] = meshgrid(-5:1:5,-5:1:5); Z = X; %%%%%%%%%%% CHANGE %%%%%%%%%%%

[x y z] = ellipsoid( centerPoint(1), centerPoint(2), centerPoint(3), radii(1), radii(2), radii(3) ); 
robotEllipsoid = surf(x, y, z);
alpha(robotEllipsoid, 0.5)
hold on
surface = surf(X, Y, Z);
axis equal
% axis([-150 150 -150 150 -150 150])
points = [X(:),Y(:),Z(:)];
algebraicDist = ((points(:,1)-centerPoint(1))/radii(1)).^2 ...
              + ((points(:,2)-centerPoint(2))/radii(2)).^2 ...
              + ((points(:,3)-centerPoint(3))/radii(3)).^2;
pointsInside = find(algebraicDist < 1); %%%%%%%%%%% CHANGE %%%%%%%%%%%
display(['There are ', num2str(size(pointsInside,1)),' points inside']);

