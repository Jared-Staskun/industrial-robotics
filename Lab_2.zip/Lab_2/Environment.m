function Environment(object)
clf
PlaceObject(object)
axis ([-3 10 -3 10 0 8])
camlight
