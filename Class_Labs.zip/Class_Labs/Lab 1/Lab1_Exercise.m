imshow('Lab1_CircularRaceTrack.jpg'); 
axis on;

hold on
T1 = se2(312.5, 550, 0)
T1_h = trplot2(T1, 'color', 'b', 'length', 50);

T2 = se2(312.5, 125, 0)
T2_h = trplot2(T2, 'color', 'r', 'length', 50);

for i=360:-1:0
    T1 = T1 * se2(2*((550-312.5)*sin((0.5*pi)/180)),0,-pi/180);
    delete(T1_h);
    T1_h = trplot2(T1, 'color', 'b', 'length', 50);
    
    T2 = T2 * se2(2*((312.5-125)*sin((0.5*pi)/180)),0,pi/180);
    delete(T2_h);
    T2_h = trplot2(T2, 'color', 'r', 'length', 50);
    
    message = sprintf('Line #1\nThe second line.\nAnd finally a third line.') 
    text(10, 50, message, 'FontSize', 10, 'Color', [.6 .2 .6]);
    
    pause(0.01);
end