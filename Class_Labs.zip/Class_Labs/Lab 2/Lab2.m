clear
clc
clf

cowHerd = RobotCows();

trOrigin = eye(4);

%% Move up 10 units
tr1 = transl(0,0,10);
tranimate(trOrigin,tr1)        
trOrigin = trOrigin * tr1;

%% Rotate around X by 10 degrees
rotateAroundXBy10deg = trotx(-10*pi/180);
tranimate(trOrigin,trOrigin * rotateAroundXBy10deg)
trOrigin = trOrigin * rotateAroundXBy10deg;

%% Move 2 units along Y
tr1 = transl(0,2*cos(10*pi/180),2*sin(10*pi/180));
tranimate(trOrigin,trOrigin * tr1)
trOrigin = trOrigin * tr1;

%% Rotate around X by -10 degrees
rotateAroundXByrev10deg = trotx(10*pi/180);
tranimate(trOrigin,trOrigin * rotateAroundXByrev10deg)
trOrigin = trOrigin * rotateAroundXByrev10deg;

%% Rotate around Y by 20 degrees
rotateAroundYBy20deg = troty(20*pi/180);
tranimate(trOrigin,trOrigin * rotateAroundYBy20deg)
trOrigin = trOrigin * rotateAroundYBy20deg;

%% Move 2 units along Y
tr1 = transl(2*cos(20*pi/180),0,2*sin(20*pi/180));
tranimate(trOrigin,trOrigin * tr1)
trOrigin = trOrigin * tr1;

%% Rotate around Y by -20 degrees
rotateAroundYByrev20deg = troty(-20*pi/180);
tranimate(trOrigin,trOrigin * rotateAroundYByrev20deg)
trOrigin = trOrigin * rotateAroundYByrev20deg;

%% Move down 10 units
tr1 = transl(0,0,-10);
tranimate(trOrigin,trOrigin * tr1)        
trOrigin = trOrigin * tr1;
