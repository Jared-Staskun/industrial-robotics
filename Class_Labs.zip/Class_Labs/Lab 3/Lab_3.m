L1 = Link('d',0,'a',1,'alpha',0,'qlim',[-pi pi])
L2 = Link('d',0,'a',1,'alpha',0,'qlim',[-pi pi])
L3 = Link('d',0,'a',1,'alpha',0,'qlim',[-pi pi])

robot = SerialLink([L1 L2 L3],'name','myRobot') 
      
q = zeros(1,3);                                                     % 

robot.plot(q,'workspace',workspace,'scale',scale);

robot.teach;

input('Press enter to continue');
q = robot.getpos()