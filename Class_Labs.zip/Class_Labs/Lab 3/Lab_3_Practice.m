%% Robot 1
L1 = Link('alpha',pi/2,'a',0,'d',1,'offset',0);
L2 = Link('alpha',0,'a',1,'d',0,'offset',pi/6);
L3 = Link('alpha',0,'a',1,'d',0,'offset',-pi/4);

robot_1 = SerialLink([L1 L2 L3],'name','Robot 1');
q = zeros(1,3);
workspace = [-4 4 -4 4 -4 4];
scale = 0.5;

robot_1.plot(q,'workspace',workspace,'scale',scale);
robot_1.teach();

%% Robot 2
L1 = Link('alpha',pi/2,'a',0,'d',0.1273,'offset',0);
L2 = Link('alpha',0,'a',0.612,'d',0,'offset',0);
L3 = Link('alpha',0,'a',0.5723,'d',0,'offset',0);
L4 = Link('alpha',pi/2,'a',0,'d',0.16394,'offset',0);
L5 = Link('alpha',pi/2,'a',0,'d',0.1157,'offset',0);
L6 = Link('alpha',0,'a',0.0922,'d',0,'offset',0);

robot_2 = SerialLink([L1 L2 L3 L4 L5 L6],'name','Robot 2');
q = zeros(1,6);
workspace = [-2 2 -2 2 -2 2];
scale = 0.2;

robot_2.plot(q,'workspace',workspace,'scale',scale);
robot_2.teach();

%% Exercise 2
L1=Link('alpha',-pi/2,'a',0.180, 'd',0.475, 'offset',0, 'qlim',[deg2rad(-170), deg2rad(170)]);
L2=Link('alpha',0,'a',0.385, 'd',0, 'offset',-pi/2, 'qlim',[deg2rad(-90), deg2rad(135)]);
L3=Link('alpha',pi/2,'a',-0.100, 'd',0, 'offset',pi/2, 'qlim',[deg2rad(-80), deg2rad(165)]);
L4=Link('alpha',-pi/2,'a',0, 'd',0.329+0.116, 'offset',0, 'qlim',[deg2rad(-185), deg2rad(185)]);
L5=Link('alpha',pi/2,'a',0, 'd',0, 'offset',0, 'qlim',[deg2rad(-120), deg2rad(120)]);
L6=Link('alpha',0,'a',0, 'd',0.09, 'offset',0, 'qlim',[deg2rad(-360), deg2rad(360)]);
    
densoRobot = SerialLink([L1 L2 L3 L4 L5 L6],'name','Denso VM6083G');
densoRobot.name = 'Denso VM6083G';

densoRobot.plotopt = {'nojoints', 'noname', 'noshadow', 'nowrist'};

stepRads = deg2rad(30);
qlim = densoRobot.qlim;

q = [0,pi/2,0,0,0,0];
densoRobot.plot(q);
hold on;
blastStartTr = densoRobot.fkine(q);
blastStartPnt = blastStartTr(1:3,4)';

blastEndTr = densoRobot.fkine(q) * transl(0,0,1);
blastEndPnt = blastEndTr(1:3,4)';

blastPlot_h = plot3([blastStartPnt(1),blastEndPnt(1)],[blastStartPnt(2),blastEndPnt(2)],[blastStartPnt(3),blastEndPnt(3)],'r');
axis equal;

planeXntersect = 1.5;
planeBounds = [planeXntersect-eps,planeXntersect+eps,-2,2,-2,2]; 
[Y,Z] = meshgrid(planeBounds(3):0.1:planeBounds(4),planeBounds(5):0.1:planeBounds(6));
X = repmat(planeXntersect,size(Y,1),size(Y,2));
surf(X,Y,Z);